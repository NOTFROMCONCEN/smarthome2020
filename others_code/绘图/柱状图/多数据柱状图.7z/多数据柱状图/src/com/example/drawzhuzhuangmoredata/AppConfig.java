package com.example.drawzhuzhuangmoredata;

public class AppConfig {
	public static float data1 = 0;
	public static float data2 = 0;
	public static float data3 = 0;
	public static float data4 = 0;
	public static float data5 = 0;
}
