package com.example.drawzhuzhuangonedata;

public class MyConfig {

	public static int runthread_time = 1000;
	public static String sql_name = "info.db";

}
