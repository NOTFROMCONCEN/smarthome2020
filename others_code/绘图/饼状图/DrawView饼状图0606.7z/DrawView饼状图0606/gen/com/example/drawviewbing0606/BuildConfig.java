/** Automatically generated file. DO NOT MODIFY */
package com.example.drawviewbing0606;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}