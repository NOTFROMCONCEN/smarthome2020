package com.example.getdatausethread;

public class AppConfig {

	public static String ip = "";// IP��ַ
	public static float temp = 0;// �¶�
	public static float ill = 0;// ����
	public static float smo = 0;// ����
	public static float press = 0;// ��ѹ
	public static float co = 0;// Co2

}
