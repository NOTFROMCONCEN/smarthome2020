package com.example.shengsaia06062019;

/**
 * @author Administrator
 * @year 2020
 * @Todo TODO APP�������ô洢
 * @package_name com.example.shengsaia06062019
 * @project_name 2019ShengSaiA0606
 * @file_name AppConfig.java
 * @�ҵĲ��� https://naiyouhuameitang.club/
 */
public class AppConfig {

	public static String ip = "";

	public static float temp = 0;
	public static float hum = 0;
	public static float ill = 0;
	public static float smo = 0;
	public static float gas = 0;
	public static float pm = 0;
	public static float per = 0;
	public static float press = 0;
	public static float co = 0;

	public static String room_number = "";

}
