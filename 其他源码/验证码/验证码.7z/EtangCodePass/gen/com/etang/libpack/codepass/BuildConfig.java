/** Automatically generated file. DO NOT MODIFY */
package com.etang.libpack.codepass;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}