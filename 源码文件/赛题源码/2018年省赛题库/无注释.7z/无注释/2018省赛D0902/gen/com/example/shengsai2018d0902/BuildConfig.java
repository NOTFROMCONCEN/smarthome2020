/** Automatically generated file. DO NOT MODIFY */
package com.example.shengsai2018d0902;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}