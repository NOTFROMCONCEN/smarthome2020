/** Automatically generated file. DO NOT MODIFY */
package com.example.shengsai2018b0901;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}