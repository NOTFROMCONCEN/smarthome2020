package com.example.shengsai2018a0901.tools;

public class AppConfig {

	public static String IP = "";
	
}
