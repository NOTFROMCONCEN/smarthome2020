/** Automatically generated file. DO NOT MODIFY */
package com.example.shengsai2018e0903;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}