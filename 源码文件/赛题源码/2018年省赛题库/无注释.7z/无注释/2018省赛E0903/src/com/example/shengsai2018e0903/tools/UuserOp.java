package com.example.shengsai2018e0903.tools;

public class UuserOp {
	public static String user_op = "";
}
