package com.example.shengsai2018c0902.tools;

public class AppConfig {

	public static String IP = "";

}
